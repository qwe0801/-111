//
//  AppDelegate.h
//  HotelManage
//
//  Created by qwe on 2021/7/1.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

