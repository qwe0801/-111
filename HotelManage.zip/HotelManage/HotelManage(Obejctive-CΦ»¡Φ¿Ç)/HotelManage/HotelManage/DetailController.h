//
//  DetaliController.h
//  HotelManage
//
//  Created by qwe on 2021/7/2.
//

#import <UIKit/UIKit.h>
#import "Hotel.h"

@interface DetailController: UIViewController
@property (weak, nonatomic) IBOutlet UILabel *hotelname;
@property (weak, nonatomic) IBOutlet UITextView *introduce;


@property(nonatomic,strong)Hotel *hotel;
@end

