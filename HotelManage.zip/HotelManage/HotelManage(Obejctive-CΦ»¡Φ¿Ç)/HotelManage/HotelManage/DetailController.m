//
//  DetaliController.m
//  HotelManage
//
//  Created by qwe on 2021/7/2.
//

#import "DetailController.h"

@interface DetailController ()

@end

@implementation DetailController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.hotelname.text=self.hotel.name;
    self.introduce.text=self.hotel.detail;
    self.navigationItem.title=@"详情介绍";
}

@end
