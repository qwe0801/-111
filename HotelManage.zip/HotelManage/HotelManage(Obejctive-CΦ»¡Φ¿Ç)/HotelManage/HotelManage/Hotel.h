//
//  Hotel.h
//  HotelManage
//
//  Created by qwe on 2021/7/2.
//

#import <Foundation/Foundation.h>

@interface Hotel : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *picture;
@property(nonatomic,copy)NSString *detail;
+(instancetype)hotelWithDict:(NSDictionary *)dict;//声明创建酒店对象的类方法
-(instancetype)initWithDict:(NSDictionary *)dict;//声明创建酒店对象的对象方法
+(NSArray *)hotels;//声明返回所有酒店的方法
@end

