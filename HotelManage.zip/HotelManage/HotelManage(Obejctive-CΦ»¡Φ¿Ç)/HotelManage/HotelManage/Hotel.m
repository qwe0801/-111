#import "Hotel.h"
@interface Hotel()
@property (nonatomic,copy)NSArray *hotelArray;
@end

@implementation Hotel
+(instancetype)hotelWithDict:(NSDictionary *)dict{
    return [[self alloc]initWithDict:dict];
}


-(instancetype)initWithDict:(NSDictionary *)dict{
    if (self=[super init]) {
        [self setValuesForKeysWithDictionary:dict];
    }
    return self;
}


+(NSArray *)hotels{
    NSString *path=[[NSBundle mainBundle]pathForResource:@"HotelList.plist" ofType:nil];
    //获取数组中的元素
    NSArray *arr=[NSArray arrayWithContentsOfFile:path];
    NSMutableArray *mutableArray=[NSMutableArray array];
    for (NSDictionary *dic in arr) {
        [mutableArray addObject:[Hotel hotelWithDict:dic]];
    }
    return mutableArray;
}
@end
