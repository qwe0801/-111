#import "ViewController.h"
#import "DetailController.h"
#import "Hotel.h"
@interface ViewController ()
@property(nonatomic,strong)NSArray *hotels;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.rowHeight=90;
    self.navigationItem.title=@"酒店列表";
}
-(NSArray *)hotels{
    if (!_hotels) {
        _hotels=[Hotel hotels];
    }
    return _hotels;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    //获取跳转的目的的控制器
    UIViewController *vc=segue.destinationViewController;
    //判断是否是目的控制器
    if ([vc isKindOfClass:[DetailController class]]) {
        DetailController *detailVc=(DetailController *)vc;
        //获取单击行所在的索引
        NSIndexPath *Path=[self.tableView indexPathForSelectedRow];
        //选中行的模型
        Hotel *hotel=self.hotels[Path.row];
        detailVc.hotel=hotel;
    }
}


-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSegueWithIdentifier:@"one" sender:self];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.hotels.count;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString *ID=@"hotel";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:ID];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
    }
    //设置cell
    Hotel *hotel=self.hotels[indexPath.row];
    cell.textLabel.text=hotel.name;
    cell.imageView.image=[UIImage imageNamed:hotel.picture];
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

@end
