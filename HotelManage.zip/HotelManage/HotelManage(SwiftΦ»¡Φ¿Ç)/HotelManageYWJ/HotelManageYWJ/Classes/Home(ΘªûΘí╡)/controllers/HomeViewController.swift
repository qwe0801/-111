//
//  HomeViewController.swift
//  HotelManageYWJ
//
//  Created by qwe on 2022/6/14.
//

import UIKit
import Alamofire
import SDCycleScrollView
import SVProgressHUD
import SnapKit
 
class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource,UITableViewDelegate, UITableViewDataSource, SDCycleScrollViewDelegate {
   
    // 轮播图
    lazy var bannerScrollView:SDCycleScrollView = {
        var bannerScrollView = SDCycleScrollView()
       
        let img1 = UIImage(named:"bannerimg1")
        let img2 = UIImage(named:"bannerimg2")
        let img3 = UIImage(named:"bannerimg3")
        let img4 = UIImage(named:"bannerimg4")
        let img5 = UIImage(named:"bannerimg5")
       
        let imgArray = [img1, img2, img3, img4,img5]
       
        bannerScrollView = SDCycleScrollView(frame: CGRect(x: 0, y: 0, width: ScreenWidth, height:SDCycleScrollViewHeight), imageNamesGroup: imgArray as! [UIImage])
       
        bannerScrollView.bannerImageViewContentMode = .scaleToFill
        bannerScrollView.showPageControl = true
        bannerScrollView.pageControlAliment = SDCycleScrollViewPageContolAlimentCenter
        bannerScrollView.autoScroll = true
        bannerScrollView.autoScrollTimeInterval = 5
        bannerScrollView.infiniteLoop = true
       
        return bannerScrollView
    }()
   
    lazy var netImages:[UIImage] = {
        let url = URL(string: "path")
        var image1 = UIImage()
        var image2 = UIImage()
        do {
            let data = try Data(contentsOf:url!)
            image1 = UIImage(data: data)!
            image2 = UIImage(data: data)!
        } catch let error as NSError {
            print(error)
        }
        return [image1,image2]
    }()
   
    //懒加载本地图片数据
    lazy var localImages:[UIImage] = {
            let img1 = UIImage(named:"bannerimg1")
            let img2 = UIImage(named:"bannerimg2")
            let img3 = UIImage(named:"bannerimg3")
            let img4 = UIImage(named:"bannerimg4")
            let img5 = UIImage(named:"bannerimg5")
            return [img1!, img2!, img3!, img4!,img5!]
        }()
   
    var cycleScrollView = SDCycleScrollView()
   
    //设备分类列表
    @IBOutlet weak var hotelKindCollectionView: UICollectionView!
    @IBOutlet weak var hotelTableview: UITableView!
    
    lazy var noInfoLabel : UILabel = {
        let label = UILabel.init(frame:CGRect(x:0,y:self.hotelTableview.center.y - 64,width:ScreenWidth,height:30))
        label.text = "该分类下暂无设备"
        label.font = UIFont.init(name:"noinfo", size: 16)
        label.textColor = UIColor.black
        label.textAlignment = .center
        return label
    }()
   
    //设备分类collectionView的数据源
    var hotelKindModelArray:hotelKindModel?
    var hotelKindBaseModelArray:[hotelKindBaseModel]?
    //设备tableView的数据源
    var hotelModelArray:hotelModel?
    var hotelBaseModelArray:[hotelBaseModel]?
   
   
    var classIdArray:[Int] = []
    var classNameArray:[String] = []
    var hotelIdArray:[Int] = []
    var hotelNameArray:[String] = []
    var hotelPriceArray:[String] = []
   
    var hotelKindNames:[String]?
    var hotelKindIds:[Int]?
   
    var hotelKindId:Int?
   
    //各控件所需尺寸定义
    let SDCycleScrollViewHeight = ScreenHeight / 3
    let UICollectionViewHeight = ScreenHeight / 4
    let UITableViewViewCellHeight:CGFloat = ScreenHeight / 7
    let CollectionCellHeight:CGFloat = 80
   
    override func viewDidLoad() {
        super.viewDidLoad()
        self.edgesForExtendedLayout = .bottom
       
        self.title = "首页"
        // Do any additional setup afterloading the view.
        self.setupUI()
    }
   
    func setupUI() {
        self.setupSDcycleScrollView()
        self.setupCollectionView()
        self.setupTableView()
    }
   
    func setupSDcycleScrollView() {       
        self.bannerScrollView.delegate = self
        self.view.addSubview(self.bannerScrollView)
    }
   
    func cycleScrollView(_ cycleScrollView:SDCycleScrollView!, didSelectItemAt index: Int) {
        print("点击了第\(index)张图片")
       
        SDCycleScrollView.clearImagesCache()
    }
   
    func cycleScrollView(_ cycleScrollView:SDCycleScrollView!, didScrollTo index: Int) {
        print(">>>>>滚动到第\(index)张图片")
    }
   
    func setupCollectionView() {
       self.view.addSubview(self.hotelKindCollectionView)
       self.getAllHotelKind()
       
       self.hotelKindCollectionView.snp.makeConstraints{ (make) in
           make.top.equalTo(self.bannerScrollView.snp_bottom)
           make.right.equalToSuperview()
           make.left.equalToSuperview()
           make.height.equalTo(UICollectionViewHeight)
        }
       
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width:(ScreenWidth - 4 * 20) / 3 , height: (UICollectionViewHeight - 3 * 10) / 2)
        layout.minimumLineSpacing = 20
        layout.minimumInteritemSpacing = 10
        layout.scrollDirection = .vertical
        layout.sectionInset = UIEdgeInsets(top:5, left: 5, bottom: 5, right: 5)
       
       self.hotelKindCollectionView.collectionViewLayout = layout
       
       
       self.hotelKindCollectionView.delegate = self
       self.hotelKindCollectionView.dataSource = self
       
       self.hotelKindCollectionView.register(UINib(nibName:"hotelKindCell", bundle: nil), forCellWithReuseIdentifier:"hotelKindCell")
       
    }
       
    @objc func getHotelByClass(btn:UIButton) {
        // 清空数组
        self.classIdArray = []
        self.hotelIdArray = []
        self.hotelNameArray = []
        self.hotelPriceArray = []
       
        self.hotelKindId = btn.tag + 1
       
        self.getAllHotelByHotelKindId()
    }
   
    func setupTableView() {
       self.view.addSubview(self.hotelTableview)
       self.hotelTableview.isHidden = true
       self.hotelTableview.snp.makeConstraints { (make) in
            make.top.equalTo(self.hotelKindCollectionView.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalToSuperview()
            make.bottom.equalToSuperview()
        }
       
        self.hotelTableview.delegate = self
        self.hotelTableview.dataSource = self
        self.hotelTableview.tableFooterView = UIView()
        self.hotelTableview.register(UINib(nibName: "hotelCell",bundle: nil), forCellReuseIdentifier: "hotelCell")
    }
   
    func getAllHotelKind() {
        SVProgressHUD.show(withStatus: "加载中")
        HotelKindNetwork.getAllHotelKind(finishedCallback: { (response) in
            print(response)
            self.hotelKindNames = []
            self.hotelKindIds = []
           
            self.hotelKindModelArray = hotelKindModel(JSON: response)
            self.hotelKindBaseModelArray = self.hotelKindModelArray?.result
            for item in self.hotelKindBaseModelArray! {
               self.hotelKindNames?.append(item.HotelKindName ?? "")
               self.hotelKindIds?.append(item.HotelKindID!)
            }
            SVProgressHUD.dismiss()
           self.hotelKindCollectionView.reloadData()
        }) {
            print("发生错误：\(#function)")
        }       
    }
   
    func getAllHotelByHotelKindId() {
        SVProgressHUD.show(withStatus: "加载中")
        let parameters:Parameters = [
           "hotelKindId":self.hotelKindId!
        ]
        HotelNetwork.findHotelByHotelKindId(parameters: parameters,finishedCallback: { (response) in
//            print(response)
            // 清空数组
            self.classIdArray = []
            self.hotelIdArray = []
            self.hotelNameArray = []
            self.hotelPriceArray = []
           
            self.hotelTableview.isHidden = false
            self.hotelModelArray = hotelModel(JSON: response)
            self.hotelBaseModelArray = self.hotelModelArray?.result
           for item in self.hotelBaseModelArray! {
               self.classIdArray.append(item.hotelKindId!)
               self.hotelIdArray.append(item.hotelID!)
               self.hotelNameArray.append(item.hotelName!)
               self.hotelPriceArray.append(item.hotelPrice!)
            }
           
            if self.hotelIdArray.count == 0 {
                self.hotelTableview.isHidden = true
                self.view.addSubview(self.noInfoLabel)
            } else {
               self.noInfoLabel.removeFromSuperview()
                self.hotelTableview.isHidden = false
            }
            SVProgressHUD.dismiss()
            self.hotelTableview.reloadData()
            
        }) {
            print("发生错误：\(#function)")
        }
    }
   
    //MARK: -实现UITableDataSource协议
    func tableView(_ tableView: UITableView,titleForHeaderInSection section: Int) -> String? {
        return "设备列表"
    }
   
    func numberOfSections(in tableView:UITableView) -> Int {
        return 1
    }
   
    func tableView(_ tableView: UITableView,numberOfRowsInSection section: Int) -> Int {
        if self.hotelBaseModelArray != nil {
            return self.hotelBaseModelArray!.count
        }
        return 0
    }
   
    func tableView(_ tableView: UITableView,heightForRowAt indexPath: IndexPath) -> CGFloat {
        return self.UITableViewViewCellHeight
    }
   
    func tableView(_ tableView: UITableView,cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "hotelCell", for:indexPath) as! hotelCell
       
        if self.hotelBaseModelArray != nil {
            cell.hotelName.text = self.hotelNameArray[indexPath.row]
            cell.hotelPrice.text = self.hotelPriceArray[indexPath.row]
           
            switch cell.hotelName.text {
            case "君悦":
                cell.hotelImgView.image = UIImage(named:"君悦")
            case "雷克泰":
                cell.hotelImgView.image = UIImage(named: "雷克泰")
            case "莫泰":
                cell.hotelImgView.image = UIImage(named: "莫泰")
            case "开元曼居":
                cell.hotelImgView.image = UIImage(named: "开元曼居")
            case "汉庭":
                cell.hotelImgView.image = UIImage(named: "汉庭")
            case "布丁":
                cell.hotelImgView.image = UIImage(named: "布丁")
            default:
                break
            }
        }
       
        return cell
    }
   
    func tableView(_ tableView: UITableView,didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath,animated: true)
        let vc = HotelDetailViewController()
        vc.hotelId = hotelIdArray[indexPath.row]
        vc.hidesBottomBarWhenPushed = true
       self.navigationController?.pushViewController(vc, animated: true)
    }
   
    //MARK: -实现UICollectionViewDataSource协议
    func numberOfSections(in collectionView:UICollectionView) -> Int {
        return 1
    }
   
    func collectionView(_ collectionView:UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.hotelKindNames != nil {
            return self.hotelKindNames!.count
        }
        return 0
    }
   
    func collectionView(_ collectionView:UICollectionView, cellForItemAt indexPath: IndexPath) ->UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"hotelKindCell", for: indexPath) as! hotelKindCell
        
        if self.hotelKindIds != nil {
            switch self.hotelKindIds![indexPath.row] {
            case 1:
                cell.imageView.image = UIImage(named: "一星级")
            case 2:
                cell.imageView.image = UIImage(named: "二星级")
            case 3:
                cell.imageView.image = UIImage(named: "三星级")
            case 4:
                cell.imageView.image = UIImage(named: "四星级")
            case 5:
                cell.imageView.image = UIImage(named: "五星级")
            case 6:
                cell.imageView.image = UIImage(named: "六星级")
            default:
                cell.imageView.image = UIImage(named: "")
            }
            cell.titleLabel.text = self.hotelKindNames![indexPath.row]
        }
        return cell
    }
   
    //MARK: -实现UICollectionViewDelegate协议
    func collectionView(_ collectionView:UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at:indexPath, animated: true)
        self.hotelKindId = indexPath.row + 1
        self.getAllHotelByHotelKindId()
    }
 
}
