//
//  HotelDetailViewController.swift
//  HotelManage
//
//  Created by qwe on 2022/6/14.
//

import UIKit
import SVProgressHUD
import Alamofire

class HotelDetailViewController: UIViewController {
   
    @IBOutlet weak var hotelID: UITextField!
    
    @IBOutlet weak var hotelPrice: UITextField!
    @IBOutlet weak var hotelName: UITextField!
    
    @IBAction func updateButton(_ sender: Any) {
        updateHotelById()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getHotel()
    }
    var hotelId: Int?
    var hotels: hotelModel?
    var hotel: [hotelBaseModel]?
    func getHotel() {
            SVProgressHUD.show(withStatus: "加载中")
            let parameters:Parameters = [
               "hotelId":self.hotelId!
            ]
            HotelNetwork.findHotelById(parameters: parameters) { response in
                print(response)
                self.hotels = hotelModel(JSON: response)
                self.hotel = self.hotels?.result
                for item in self.hotel! {
                    self.hotelID.text = (item.hotelID!).description
                    self.hotelName.text = item.hotelName
                    self.hotelPrice.text = item.hotelPrice
                }
                SVProgressHUD.dismiss()
            } failture: {
                print("发生错误：\(#function)")
            }
        }
        
        func updateHotelById() {
            let paramters: Parameters = [
                "hotelId": self.hotelId!,
                "hotelName": self.hotelName.text!,
                "hotelPrice": self.hotelPrice.text!
            ]
            HotelNetwork.updateHotelById(parameters: paramters) { response in
                SVProgressHUD.showInfo(withStatus: "修改成功")
                SVProgressHUD.dismiss(withDelay: 2)
            } failture: {
                print("发生错误：\(#function)")
            }

        }
    
}
