//
//  hotelKindModel.swift
//  HoteleManageYWJ
//
//  Created by qwe on 2022/6/14.
//

import Foundation
import ObjectMapper

class  hotelKindModel:Mappable{
    var result:[hotelKindBaseModel]?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        result <- map["result"]
    }
}
class  hotelKindBaseModel:Mappable {
    var HotelKindID:Int?
    var HotelKindName:String?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        HotelKindID   <- map["HotelKindID"]
        HotelKindName <- map["HotelKindName"]
    }
}
