//
//  hotelModel.swift
//  HotelManageYWJ
//
//  Created by qwe on 2022/6/14.
//

import Foundation
import ObjectMapper
 
class hotelModel: Mappable {
    var result:[hotelBaseModel]?
   
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        result <- map["result"]
    }
   
}
 
class hotelBaseModel: Mappable {
   
    var hotelKindId:Int?
    var hotelID:Int?
    var hotelName:String?
    var hotelPrice:String?
   
    required init?(map: Map) {
       
    }
   
    func mapping(map: Map) {
        hotelKindId    <- map["HotelKindId"]
        hotelID        <- map["HotelID"]
        hotelName      <- map["HotelName"]
        hotelPrice     <- map["HotelPrice"]
    }
   
}
