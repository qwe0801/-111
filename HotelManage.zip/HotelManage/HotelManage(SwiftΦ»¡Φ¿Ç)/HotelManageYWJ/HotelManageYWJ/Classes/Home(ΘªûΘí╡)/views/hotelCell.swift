//
//  hotelCell.swift
//  HotelManage
//
//  Created by zjc16 on 2022/5/31.
//

import UIKit

class hotelCell: UITableViewCell {
    @IBOutlet weak var hotelImgView: UIImageView!
    @IBOutlet weak var hotelName: UILabel!
    
    @IBOutlet weak var hotelPrice: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
