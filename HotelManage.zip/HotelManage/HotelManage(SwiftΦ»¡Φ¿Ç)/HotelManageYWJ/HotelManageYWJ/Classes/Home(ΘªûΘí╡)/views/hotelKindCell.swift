//
//  hotelKindCell.swift
//  HotelManage
//
//  Created by zjc16 on 2022/5/31.
//

import UIKit

class hotelKindCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        titleLabel.adjustsFontSizeToFitWidth=true
    }
    
}
