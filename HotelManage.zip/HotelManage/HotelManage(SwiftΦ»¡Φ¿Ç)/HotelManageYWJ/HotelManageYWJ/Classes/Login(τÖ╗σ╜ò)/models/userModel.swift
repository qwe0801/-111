//
//  userModel.swift
//  DeviceManage
//
//  Created by qwe on 2022/5/10.
//

import Foundation
import ObjectMapper

class  userModel:Mappable {
    var result:[userBaseModel]?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        result <- map["result"]
    }
}
class userBaseModel: Mappable {
    var userName:String?
    var userID:Int?
    var userPassword:String?
    required init?(map: Map) {
    }
    func mapping(map: Map) {
        userName          <- map["UserName"]
        userID            <- map["UserID"]
        userPassword      <- map["UserPassword"]
    }
}
