//
//  MainViewController.swift
//  HotelMangeYWJ
//
//  Created by qwe on 2022/6/14.
//

import UIKit

class MainViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBar.barTintColor = UIColor.white
    }
    private func addItem(VC:UIViewController,tabtitle:String, tabimg:String, tabselectImg:String, index:Int) {
            let navi = UINavigationController(rootViewController: VC)
            
            VC.title = tabtitle
            VC.tabBarItem.tag = index
            
            VC.tabBarItem.imageInsets = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
            VC.tabBarItem.image = UIImage(named:tabimg)?.withRenderingMode(.alwaysOriginal)
            VC.tabBarItem.selectedImage = UIImage(named: tabselectImg)?.withRenderingMode(.alwaysOriginal)
            
            self.addChild(navi)
        }
    private func setupViewControllers() {
            self.addItem(VC: HomeViewController(), tabtitle: "首页", tabimg: "home", tabselectImg: "home_click", index: 0)
        }
    init() {
           super.init(nibName: nil, bundle: nil)
           
           self.tabBar.barTintColor = UIColor.white
           self.tabBar.isTranslucent = false
           self.setupViewControllers()
       }
       
       required init?(coder: NSCoder) {
           fatalError("init(coder:) has not been implemented")
       }
}
