//
//  GlobalDefine.swift
//  HotelManage
//
//  Created by qwe on 2022/6/14.
//

import Foundation
import UIKit
 
class GlobalDefine {
    
    // API基础网址
    static let baseURL = "http://192.168.31.129:8080/HotelManage/"
    
    //状态栏 + 导航栏高度
    static let naviHeight = UINavigationController().navigationBar.frame.height + UIApplication.shared.statusBarFrame.height
    //tabbar高度
    static let tabbarHeight = UITabBar().frame.height
}
 
let ScreenWidth = UIScreen.main.bounds.width
let ScreenHeight = UIScreen.main.bounds.height
