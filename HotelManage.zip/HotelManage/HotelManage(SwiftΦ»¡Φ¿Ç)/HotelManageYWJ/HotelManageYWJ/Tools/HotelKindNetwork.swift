//
//  HotelKindNetwork.swift
//  HotelManage
//
//  Created by qwe on 2022/6/14.
//

import Foundation
class HotelKindNetwork {
    static func getAllHotelKind(finishedCallback: @escaping (_ result:[String: Any]) -> (),failture: @escaping ()->()) {
        let url = GlobalDefine.baseURL  + "findAllHotelKind"
        NetworkTool.shareInstance.requestJsonData(.get, URLString: url) { response in
            finishedCallback(response)
        } failture: { _ in
            failture()
        }
    }
    
}
