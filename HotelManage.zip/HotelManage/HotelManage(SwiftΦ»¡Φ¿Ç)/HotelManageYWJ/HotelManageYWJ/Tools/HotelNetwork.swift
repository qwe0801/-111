//
//  HotelNetwork.swift
//  HotelManage
//
//  Created by qwe on 2022/5/31.
//

import Foundation
class HotelNetwork {
    static func findHotelById(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "findHotelById"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
    static func findHotelByHotelKindId(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "findHotelByHotelKindId"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
        static func updateHotelById(parameters:[String:Any]? = nil,
                              finishedCallback: @escaping (_ result:[String:Any])->(),
                              failture: @escaping ()->()) {
            let url = GlobalDefine.baseURL + "updateHotelById"
            NetworkTool.shareInstance.requestJsonData(.get, URLString: url, parameters: parameters, success: {
                (response) in
                print(response)
                finishedCallback(response)
            }) {
                (_) in
                failture()
            }
        }
    
}

