//
//  NetworkTool.swift
//  HotelManageYWJ
//
//  Created by qwe on 2022/6/14.
//

import UIKit
import Alamofire
class NetworkTool: NSObject {
    static let shareInstance:NetworkTool = {
        let tools = NetworkTool()
        return tools
    }()
}
extension NetworkTool{
    func requestJsonData(_ type:HTTPMethod,
                        URLString:String,parameters:[String : Any]? = nil,
                        success:@escaping (_ responeObject:[String:Any])->(),
                         failture:@escaping (_ error:NSError)->()){
        Alamofire.request(URLString,method: type,parameters: parameters).responseJSON{
            (response) in
            if response.response?.statusCode == 200{
                let json = response.result.value as? [String:Any]
                success(json! as [String:AnyObject])
                return
            }else{
                let error = NSError.init()
                failture(error)
            }
        }
    }
}
