/*
 Navicat Premium Data Transfer

 Source Server         : MYSQL57
 Source Server Type    : MySQL
 Source Server Version : 50730
 Source Host           : localhost:3306
 Source Schema         : HotelManage

 Target Server Type    : MySQL
 Target Server Version : 50730
 File Encoding         : 65001

 Date: 15/06/2022 20:34:07
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for Hotel
-- ----------------------------
DROP TABLE IF EXISTS `Hotel`;
CREATE TABLE `Hotel` (
  `HotelID` int(11) NOT NULL AUTO_INCREMENT,
  `HotelKindID` int(11) NOT NULL,
  `HotelName` varchar(255) DEFAULT NULL,
  `HotelPrice` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`HotelID`),
  KEY `HotelKindID` (`HotelKindID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Hotel
-- ----------------------------
BEGIN;
INSERT INTO `Hotel` VALUES (1, 1, '君悦', '1000');
INSERT INTO `Hotel` VALUES (2, 2, '雷克泰', '2000');
INSERT INTO `Hotel` VALUES (3, 3, '莫泰', '3000');
INSERT INTO `Hotel` VALUES (4, 4, '格林豪泰', '4000');
INSERT INTO `Hotel` VALUES (5, 5, '开元曼居', '5000');
INSERT INTO `Hotel` VALUES (6, 6, '汉庭', '10000');
INSERT INTO `Hotel` VALUES (7, 7, '布丁', '11111');
COMMIT;

-- ----------------------------
-- Table structure for HotelKind
-- ----------------------------
DROP TABLE IF EXISTS `HotelKind`;
CREATE TABLE `HotelKind` (
  `HotelKindID` int(11) NOT NULL AUTO_INCREMENT,
  `HotelKindName` varchar(255) NOT NULL,
  PRIMARY KEY (`HotelKindID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of HotelKind
-- ----------------------------
BEGIN;
INSERT INTO `HotelKind` VALUES (1, '一星级');
INSERT INTO `HotelKind` VALUES (2, '二星级');
INSERT INTO `HotelKind` VALUES (3, '三星级');
INSERT INTO `HotelKind` VALUES (4, '四星级');
INSERT INTO `HotelKind` VALUES (5, '五星级');
INSERT INTO `HotelKind` VALUES (6, '六星级');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
