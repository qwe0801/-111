package zjc.manage.service;


import zjc.manage.dao.HotelkindMapper;

import javax.annotation.Resource;

public class HotelKindService {
    @Resource
    private HotelkindMapper hotelkindMapper;





}
