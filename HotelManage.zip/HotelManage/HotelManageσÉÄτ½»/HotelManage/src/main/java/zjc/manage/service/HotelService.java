package zjc.manage.service;

public class HotelService {
}
