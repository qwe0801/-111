package zjc.manage.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zjc.manage.dao.HotelMapper;
import zjc.manage.domain.Hotel;
import zjc.manage.domain.HotelExample;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/HotelManage")
public class HotelController {

    @Resource
    private HotelMapper hotelMapper;

    /*app端调用URL（http://127.0.0.1:8080/HotelManage/findAllHotel）时调用*/
    @GetMapping("/findAllHotel")
    public Object findAllHotel() throws IOException {
        HotelExample example = new HotelExample();
        List<Hotel> list = hotelMapper.selectByExample(example);
        return makeJson(list);
    }

    /*app端调用URL（http://127.0.0.1:8080/HotelManage/findHotelByHotelKindId? hotelKindId=1）时，
    将通过hotelKindId=1传递参数，并通过request对象的getParameter方法可以得到参数hotelKindId的值为1*/
    @GetMapping("/findHotelByHotelKindId")
    public Object findHotelByHotelKindId(int hotelKindId) throws IOException {
        HotelExample example = new HotelExample();
        HotelExample.Criteria criteria = example.createCriteria();
        criteria.andHotelkindidEqualTo(hotelKindId);
        List<Hotel> list = hotelMapper.selectByExample(example);
        return makeJson(list);
    }

    /*app端调用URL（http://127.0.0.1:8080/HotelManage/findHotelById?hotelId=1）时，
    将通过hotelId=1传递参数，并通过request对象的getParameter方法可以得到参数hotelKindId的值为1*/
    @GetMapping("/findHotelById")
    public Object findHotelById(int hotelId) throws IOException {
        HotelExample example = new HotelExample();
        HotelExample.Criteria criteria = example.createCriteria();
        criteria.andHotelidEqualTo(hotelId);
        List<Hotel> list = hotelMapper.selectByExample(example);
        return makeJson(list);
    }

    public Object makeJson(List<Hotel> list) throws IOException{
        JSONArray jsonArray = new JSONArray();
        for(Hotel dev: list){
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("HotelID", dev.getHotelid());
            // 设备编号要通过Hotelkind子对象间接获得
            jsonObj.put("HotelKindId", dev.getHotelkindid());
            jsonObj.put("HotelName", dev.getHotelname());
            jsonObj.put("HotelPrice", dev.getHotelprice());
            jsonArray.add(jsonObj);
        }
        System.out.println(jsonArray.toString());
        JSONObject root = new JSONObject();
        root.put("result", jsonArray);
        return root;
    }
}
