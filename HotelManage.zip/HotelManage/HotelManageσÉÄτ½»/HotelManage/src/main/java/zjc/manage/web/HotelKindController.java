package zjc.manage.web;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import zjc.manage.dao.HotelkindMapper;
import zjc.manage.domain.Hotelkind;
import zjc.manage.domain.HotelkindExample;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;


@RestController
@RequestMapping("/HotelManage")
public class HotelKindController {


    @Resource
    private HotelkindMapper hotelkindMapper;

    @GetMapping("/findAllHotelKind")
    public Object findAllHotelKind() throws IOException {
        HotelkindExample example = new HotelkindExample();
        List<Hotelkind> list = hotelkindMapper.selectByExample(example);
        return makeJson(list);
    }

    @GetMapping("/findHotelKind")
    public Object findHotelKind(int hotelkindId) throws IOException{

        HotelkindExample example = new HotelkindExample();
        example.or().andHotelkindidEqualTo(hotelkindId);
        List<Hotelkind> list = hotelkindMapper.selectByExample(example);
        return makeJson(list);
    }

    public Object makeJson(List<Hotelkind> list) throws IOException {

        JSONArray jsonArray = new JSONArray();
        //循环获得数据
        for (Hotelkind dc : list) {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("HotelKindID", dc.getHotelkindid());
            jsonObj.put("HotelKindName", dc.getHotelkindname());
            jsonArray.add(jsonObj);
        }

        JSONObject root = new JSONObject();
        root.put("result", jsonArray);
        return root;
    }


}
